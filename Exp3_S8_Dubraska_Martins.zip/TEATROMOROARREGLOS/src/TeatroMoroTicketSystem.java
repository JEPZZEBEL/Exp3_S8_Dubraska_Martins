import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class TeatroMoroTicketSystem {
 
    private final String nombreTeatro;
    private final HashMap<String, Integer> preciosUbicaciones;
    private final int capacidadSala;
    private final int[][] asientosDisponibles;

    private static int totalIngresos = 0;
    private static int totalEntradasVendidas = 0;

    // Lista para almacenar las ventas
    private final ArrayList<Venta> ventas = new ArrayList<>();

    // Constructor
    public TeatroMoroTicketSystem(String nombreTeatro, HashMap<String, Integer> preciosUbicaciones, int capacidadSala) {
        this.nombreTeatro = nombreTeatro;
        this.preciosUbicaciones = preciosUbicaciones;
        this.capacidadSala = capacidadSala;
        this.asientosDisponibles = new int[capacidadSala][capacidadSala];
        // Inicializar asientos disponibles
        for (int i = 0; i < capacidadSala; i++) {
            for (int j = 0; j < capacidadSala; j++) {
                this.asientosDisponibles[i][j] = 1; // 1 indica que el asiento está disponible
            }
        }
    }

    // Método para mostrar el menú interactivo
    public void mostrarMenu() {
        try (Scanner scanner = new Scanner(System.in)) {
            boolean salir = false;
            while (!salir) {
                System.out.println("---- Menu ----");
                System.out.println("1. Venta de entradas");
                System.out.println("2. Visualizar resumen de ventas");
                System.out.println("3. Generar boleta");
                System.out.println("4. Eliminar entrada");
                System.out.println("5. Modificar entrada");
                System.out.println("6. Ver plano de asientos");
                System.out.println("7. Calcular Ingresos Totales");
                System.out.println("8. Salir del Programa");
                System.out.print("Seleccione una opcion: ");
                int opcion;
                try {
                    opcion = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Debe ingresar un numero.");
                    scanner.nextLine(); // Limpiar el buffer del scanner
                    continue;
                }
                switch (opcion) {
                    case 1 -> ventaEntradas(scanner);
                    case 2 -> visualizarResumenVentas();
                    case 3 -> generarBoleta();
                    case 4 -> eliminarEntrada(scanner);
                    case 5 -> modificarEntrada(scanner);
                    case 6 -> mostrarPlanoAsientos();
                    case 7 -> calcularIngresosTotales();
                    case 8 -> {
                        System.out.println("Gracias por su compra");
                        salir = true;
                    }
                    default -> System.out.println("Opcion no valida");
                }
            }
        }
    }

    // Método para realizar la venta de entradas
    private void ventaEntradas(Scanner scanner) {
        System.out.println("---- Venta de Entradas ----");
        System.out.print("RUT del cliente (solo numeros): ");
        String rutCliente = scanner.next();
        if (!rutCliente.matches("\\d+")) {
            System.out.println("RUT no valido. Debe ingresar solo numeros.");
            return;
        }
        System.out.print("Nombre del cliente (solo letras): ");
        scanner.nextLine(); // Consumir el salto de línea
        String nombreCliente = scanner.nextLine();
        if (!nombreCliente.matches("[a-zA-Z ]+")) {
            System.out.println("Nombre no valido. Debe ingresar solo letras.");
            return;
        }
        System.out.print("Seleccione la ubicacion (VIP, PLATEA, BALCON): ");
        String ubicacion = scanner.next();
        Integer precioBase = preciosUbicaciones.get(ubicacion);

        if (precioBase == null) {
            System.out.println("Ubicacion no valida");
            return;
        }

        System.out.print("Fila del asiento: ");
        int filaAsiento = scanner.nextInt();
        System.out.print("Columna del asiento: ");
        int columnaAsiento = scanner.nextInt();

        if (!esAsientoValido(filaAsiento, columnaAsiento)) {
            System.out.println("La fila o columna del asiento no es valida");
            return;
        }

        if (asientosDisponibles[filaAsiento - 1][columnaAsiento - 1] == 0) {
            System.out.println("El asiento seleccionado no esta disponible");
            return;
        }

        System.out.print("Es estudiante? (SI/NO): ");
        boolean esEstudiante = scanner.next().equalsIgnoreCase("si");
        System.out.print("Es de la tercera edad? (SI/NO): ");
        boolean esPersonaMayor = scanner.next().equalsIgnoreCase("si");

        int descuento = 0;
        if (esEstudiante) {
            descuento = 10;
        } else if (esPersonaMayor) {
            descuento = 15;
        }

        int costoFinal = precioBase - (precioBase * descuento / 100);

        // Disponibilidad de entradas
        if (asientosDisponibles[filaAsiento - 1][columnaAsiento - 1] == 1) {
            asientosDisponibles[filaAsiento - 1][columnaAsiento - 1] = 0; // Marcar asiento como ocupado
            totalEntradasVendidas++;
            totalIngresos += costoFinal;
            int entradasDisponibles = actualizarEntradasDisponibles(ubicacion); // Actualizar cantidad de entradas disponibles
            ventas.add(new Venta(rutCliente, nombreCliente, ubicacion, filaAsiento, columnaAsiento, costoFinal, descuento, entradasDisponibles));
            System.out.println("Venta realizada con Exito!");
        } else {
            System.out.println("Lo siento, el asiento seleccionado ya esta ocupado.");
        }
    }
    
    // Método para actualizar la cantidad de entradas disponibles
    private int actualizarEntradasDisponibles(String ubicacion) {
        int entradas = 0;
        for (int i = 0; i < capacidadSala; i++) {
            for (int j = 0; j < capacidadSala; j++) {
                if (ubicacion.equals("VIP") && preciosUbicaciones.containsKey("VIP")) {
                    if (asientosDisponibles[i][j] == 1) {
                        entradas++;
                    }
                } else if (ubicacion.equals("PLATEA") && preciosUbicaciones.containsKey("PLATEA")) {
                    if (asientosDisponibles[i][j] == 1) {
                        entradas++;
                    }
                } else if (ubicacion.equals("BALCON") && preciosUbicaciones.containsKey("BALCON")) {
                    if (asientosDisponibles[i][j] == 1) {
                        entradas++;
                    }
                }
            }
        }
        return entradas;
    }

    // Método para visualizar el resumen de ventas
    private void visualizarResumenVentas() {
        System.out.println("---- Resumen de Ventas ----");
        for (Venta venta : ventas) {
            System.out.println("RUT Cliente: " + venta.rutCliente);
            System.out.println("Nombre Cliente: " + venta.nombreCliente);
            System.out.println("Ubicacion: " + venta.ubicacion);
            System.out.println("Fila Asiento: " + venta.filaAsiento);
            System.out.println("Columna Asiento: " + venta.columnaAsiento);
            System.out.println("Costo Final: " + venta.costoFinal);
            System.out.println("Descuento aplicado: " + venta.descuento + "%");
            System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
            System.out.println("--------------------------");
        }
    }

    // Método para generar la boleta
    private void generarBoleta() {
        System.out.println("-------------------------");
        System.out.println("      TEATRO MORO     ");
        System.out.println("-------------------------");
        System.out.println("        Boleta         ");
        System.out.println("-------------------------");
        for (Venta venta : ventas) {
            System.out.println("ID Venta: " + venta.idVenta);
            System.out.println("RUT Cliente: " + venta.rutCliente);
            System.out.println("Nombre Cliente: " + venta.nombreCliente);
            System.out.println("Ubicacion: " + venta.ubicacion);
            System.out.println("Asiento: Fila " + venta.filaAsiento + ", Columna " + venta.columnaAsiento);
            System.out.println("Costo Final: " + venta.costoFinal);
            System.out.println("Descuento aplicado: " + venta.descuento + "%");
            System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
            System.out.println("--------------------------");
        }
        System.out.println("  Gracias por su compra   ");
        System.out.println("--------------------------");
    }

    // Método para calcular los ingresos totales
    private void calcularIngresosTotales() {
        System.out.println("Ingresos Totales: " + totalIngresos);
    }
    
    // Método para mostrar el plano de asientos
    private void mostrarPlanoAsientos() {
        System.out.println("---- Plano de Asientos ----");
        System.out.println("Asientos disponibles (0) y ocupados (X):");
        for (int i = 0; i < capacidadSala; i++) {
            for (int j = 0; j < capacidadSala; j++) {
                if (asientosDisponibles[i][j] == 1) {
                    System.out.print("0 ");
                } else {
                    System.out.print("X ");
                }
            }
            System.out.println();
        }
        System.out.println("--------------------------");
    }

    // Método para eliminar una entrada existente
    private void eliminarEntrada(Scanner scanner) {
        System.out.println("Ingrese el RUT del cliente cuya entrada desea eliminar:");
        String rutCliente = scanner.next();
        boolean encontrado = false;
        for (Venta venta : ventas) {
            if (venta.rutCliente.equals(rutCliente)) {
                encontrado = true;
                System.out.println("Entrada encontrada:");
                System.out.println("RUT Cliente: " + venta.rutCliente);
                System.out.println("Nombre Cliente: " + venta.nombreCliente);
                System.out.println("Ubicación: " + venta.ubicacion);
                System.out.println("Fila Asiento: " + venta.filaAsiento);
                System.out.println("Columna Asiento: " + venta.columnaAsiento);
                System.out.println("Costo Final: " + venta.costoFinal);
                System.out.println("Descuento aplicado: " + venta.descuento + "%");
                System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
                System.out.println("Desea eliminar esta entrada? (SI/NO)");
                String respuesta = scanner.next();
                if (respuesta.equalsIgnoreCase("SI")) {
                    // Eliminar entrada
                    ventas.remove(venta);
                    System.out.println("Entrada eliminada correctamente.");
                    // Liberar el asiento
                    asientosDisponibles[venta.filaAsiento - 1][venta.columnaAsiento - 1] = 1;
                } else {
                    System.out.println("Entrada no eliminada.");
                }
                break;
            }
        }
        if (!encontrado) {
            System.out.println("RUT de cliente no encontrado.");
        }
    }

    // Método para modificar una entrada existente
    private void modificarEntrada(Scanner scanner) {
        System.out.println("Ingrese el RUT del cliente cuya entrada desea modificar:");
        String rutCliente = scanner.next();
        boolean encontrado = false;
        for (Venta venta : ventas) {
            if (venta.rutCliente.equals(rutCliente)) {
                encontrado = true;
                System.out.println("Entrada encontrada:");
                System.out.println("RUT Cliente: " + venta.rutCliente);
                System.out.println("Nombre Cliente: " + venta.nombreCliente);
                System.out.println("Ubicación: " + venta.ubicacion);
                System.out.println("Fila Asiento: " + venta.filaAsiento);
                System.out.println("Columna Asiento: " + venta.columnaAsiento);
                System.out.println("Costo Final: " + venta.costoFinal);
                System.out.println("Descuento aplicado: " + venta.descuento + "%");
                System.out.println("Entradas Disponibles: " + venta.entradasDisponibles);
                System.out.println("Desea modificar esta entrada? (SI/NO)");
                String respuesta = scanner.next();
                if (respuesta.equalsIgnoreCase("SI")) {
                    // Liberar el asiento actual
                    asientosDisponibles[venta.filaAsiento - 1][venta.columnaAsiento - 1] = 1;
                    // Realizar una nueva venta
                    ventaEntradas(scanner);
                    // Eliminar la entrada anterior
                    ventas.remove(venta);
                } else {
                    System.out.println("Entrada no modificada.");
                }
                break;
            }
        }
        if (!encontrado) {
            System.out.println("RUT de cliente no encontrado.");
        }
    }

    // Método para verificar si un asiento es válido
    private boolean esAsientoValido(int fila, int columna) {
        return fila >= 1 && fila <= capacidadSala && columna >= 1 && columna <= capacidadSala;
    }

    // Clase interna para representar una venta
    private static class Venta {
        private static int contadorID = 1;
        private final int idVenta;
        private final String rutCliente;
        private final String nombreCliente;
        private final String ubicacion;
        private final int filaAsiento;
        private final int columnaAsiento;
        private final int costoFinal;
        private final int descuento;
        private final int entradasDisponibles;

        public Venta(String rutCliente, String nombreCliente, String ubicacion, int filaAsiento, int columnaAsiento, int costoFinal, int descuento, int entradasDisponibles) {
            this.idVenta = contadorID++;
            this.rutCliente = rutCliente;
            this.nombreCliente = nombreCliente;
            this.ubicacion = ubicacion;
            this.filaAsiento = filaAsiento;
            this.columnaAsiento = columnaAsiento;
            this.costoFinal = costoFinal;
            this.descuento = descuento;
            this.entradasDisponibles = entradasDisponibles;
        }
    }

    // Método main
    public static void main(String[] args) {
        HashMap<String, Integer> preciosUbicaciones = new HashMap<>();
        preciosUbicaciones.put("VIP", 200000);
        preciosUbicaciones.put("PLATEA", 150000);
        preciosUbicaciones.put("BALCON", 100000);

        TeatroMoroTicketSystem sistema = new TeatroMoroTicketSystem("Teatro Moro", preciosUbicaciones, 15);
        sistema.mostrarMenu();
    }
}
